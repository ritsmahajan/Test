﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThirdPartyTools;

namespace FileData
{
    public class FileDataLogic
    {
        public string ProcessData()
        {
            string[] args = Environment.GetCommandLineArgs();
            string result = "";
            if (args.Length == 3)
            {
                FileDetails fd = new FileDetails();
                string[] optionList1 = new string[] { "'-v", "'--v", "'/v", "'--version" };
                string[] optionList2 = new string[] { "'-s", "'--s", "'/s", "'--size" };
             
                if (args[1] == "'-v")
                {
                    result=fd.Version(args[2]);

                }
                else  if (optionList1.Contains(args[1]))
                {
                   result=fd.Version(args[2]);

                }

                else if (optionList2.Contains(args[1]))
                {
                   result=fd.Size(args[2]).ToString();

                }

            }
            else
            
                result="Please enter total 2 arguments";
            return result;
            
        }
    }
}
