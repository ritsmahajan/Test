﻿using System;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;

namespace FileData
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            FileDataLogic logic = new FileDataLogic();
            Console.WriteLine(logic.ProcessData());
            Console.ReadLine();
        }

       
    }
}
