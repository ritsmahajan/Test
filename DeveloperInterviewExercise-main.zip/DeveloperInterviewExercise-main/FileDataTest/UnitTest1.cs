﻿using System;
using FileData;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using ThirdPartyTools;

namespace FileDataTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestProcessData()
        {
            Mock<FileDetails> d = new Mock<FileDetails>();
            Mock<FileDataLogic> dl = new Mock<FileDataLogic>();
            //string  arg1 = "'-v";
            d.Setup(x => x.Version(It.IsAny<string>())).Returns("1.1");
        
            var result = dl.Object.ProcessData();

            string expected = "1.1";

            Assert.AreEqual(expected, result);

        }
    }
}
